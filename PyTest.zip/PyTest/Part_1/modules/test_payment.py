import pytest

class TestPayment:
    def test_PaymentInDollar(self, setup):
        print("This is Signup by Payment In Dollar...")
        assert True == True

    def test_PaymentInRupee(self, setup):
        print("This is Payment In Rupee...")
        assert True == True
