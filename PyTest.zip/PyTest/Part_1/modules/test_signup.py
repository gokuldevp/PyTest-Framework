import pytest

class TestLogin:
    def test_SignupByEmail(self, setup):
        print("This is Signup by Email...")
        assert True == True

    def test_SignupByFacebook(self, setup):
        print("This is Signup by Facebook...")
        assert True == True

    def test_SignupByTwitter(self, setup):
        print("This is Signup by Twitter...")
        assert True == True